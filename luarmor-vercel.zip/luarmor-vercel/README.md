# 🔐 LuaArmor Clone - Vercel Edition

A fully serverless Luau script hosting platform that deploys to Vercel. Upload, manage, and serve your Roblox scripts with a beautiful dashboard!

## 🚀 Quick Deploy to Vercel

### Method 1: One-Click Deploy (Easiest)

1. Click this button: [![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=YOUR_GITHUB_REPO_URL)
2. Sign in with GitHub
3. Done! Your site is live 🎉

### Method 2: GitHub + Vercel (Recommended)

1. **Create GitHub Repository**
   - Go to [GitHub.com](https://github.com)
   - Click "New Repository"
   - Name it (e.g., `luarmor-clone`)
   - Make it public or private
   - Don't initialize with README

2. **Upload Your Code**
   ```bash
   cd luarmor-vercel
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```

3. **Deploy to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Sign up/Login with GitHub
   - Click "Add New" → "Project"
   - Import your GitHub repository
   - Vercel will auto-detect settings
   - Click "Deploy"
   - Wait 1-2 minutes ⏳
   - Your site is live! 🎉

4. **Set Your API Key (Optional)**
   - Go to your Vercel project dashboard
   - Click "Settings" → "Environment Variables"
   - Add variable: `API_KEY` = your custom key
   - Redeploy the project

## 🔑 Your API Key

Default API Key:
```
sk_live_9f8e7d6c5b4a3f2e1d0c9b8a7f6e5d4c3b2a1f0e9d8c7b6a5f4e3d2c1b0a
```

**⚠️ IMPORTANT: Change this before deploying!**

## 📖 How to Use

### 1. Access Your Site
After deploying, you'll get a URL like: `https://your-project.vercel.app`

### 2. Login
- Enter your API key
- Click "Access Dashboard"

### 3. Upload Scripts
- Give your script a name
- Paste your Luau code
- Click "Upload Script"
- Copy the loadstring!

### 4. Use in Roblox
```lua
loadstring(game:HttpGet("https://your-project.vercel.app/raw/abc123de"))()
```

## 🎨 Features

✅ **Serverless** - No server to maintain  
✅ **Free Hosting** - Vercel free tier is generous  
✅ **Auto-scaling** - Handles any traffic  
✅ **HTTPS** - Secure by default  
✅ **Custom Domain** - Add your own domain  
✅ **Beautiful UI** - LuaArmor-inspired design  
✅ **API Key Auth** - Secure dashboard access  
✅ **Instant Deploy** - Push to GitHub = Auto deploy  

## 🗄️ Storage (Important!)

**Current Setup**: Uses **in-memory storage**
- ⚠️ Scripts are lost when Vercel cold-starts (after ~15 minutes of inactivity)
- ✅ Perfect for testing and development
- ❌ Not suitable for production

**For Persistent Storage** (Production):

You need to add a database. Options:

### Option 1: MongoDB Atlas (Recommended - Free Tier Available)

1. Create account at [MongoDB Atlas](https://www.mongodb.com/atlas)
2. Create a free cluster
3. Get connection string
4. Update `api/index.py`:

```python
import os
from pymongo import MongoClient

# Add at top of file
MONGO_URI = os.environ.get('MONGO_URI', 'your-connection-string')
client = MongoClient(MONGO_URI)
db = client['luarmor']
scripts_collection = db['scripts']

# Replace SCRIPTS_STORAGE with database queries
```

5. Add to `requirements.txt`:
```
pymongo
```

6. Add environment variable in Vercel:
   - `MONGO_URI` = your MongoDB connection string

### Option 2: Vercel KV (Redis - Built-in)

1. Enable Vercel KV in your project settings
2. Update code to use KV store
3. No external service needed!

### Option 3: PostgreSQL (Vercel Postgres)

1. Enable Vercel Postgres in settings
2. Use provided connection string
3. Update code accordingly

## 📁 Project Structure

```
luarmor-vercel/
├── api/
│   └── index.py          # Main serverless function
├── vercel.json           # Vercel configuration
├── requirements.txt      # Python dependencies
├── .gitignore           # Git ignore rules
└── README.md            # This file
```

## 🔧 Configuration

### Change API Key

**Option 1: Environment Variable (Recommended)**
- In Vercel dashboard: Settings → Environment Variables
- Add: `API_KEY` = your-secure-key
- Redeploy

**Option 2: In Code**
- Edit `vercel.json`, line 21
- Change the `API_KEY` value
- Commit and push

### Custom Domain

1. Go to Vercel project settings
2. Click "Domains"
3. Add your domain
4. Update DNS records as shown
5. Wait for SSL certificate (automatic)

## 🔄 Automatic Deployments

Once connected to GitHub:
- Every `git push` = automatic deploy
- Pull requests = preview deployments
- Main branch = production deploy

```bash
# Make changes
git add .
git commit -m "Update feature"
git push

# Vercel automatically deploys! 🚀
```

## 🐛 Troubleshooting

### "Script not found" after some time
- **Cause**: In-memory storage cleared
- **Fix**: Add persistent database (see Storage section)

### "Invalid API key" after deploy
- **Check**: Environment variable is set correctly
- **Fix**: Go to Vercel Settings → Environment Variables

### Site not loading
- **Check**: Build logs in Vercel dashboard
- **Common**: Python syntax errors
- **Fix**: Check the "Deployments" tab for error details

### Can't upload scripts
- **Check**: API key is correct
- **Check**: Browser console for errors (F12)
- **Check**: Vercel function logs

## 🔒 Security Best Practices

1. **Change Default API Key** immediately
2. Use **environment variables** for secrets
3. Enable **Vercel password protection** (Settings → Password Protection)
4. Consider adding **rate limiting** for production
5. Monitor **usage** in Vercel dashboard

## 💾 Backup Your Scripts

Since in-memory storage is temporary:

1. **Before Adding Database**: Copy scripts regularly
2. **After Adding Database**: Set up backups
3. **MongoDB Atlas**: Has automatic backups
4. **Local Backup**: Use the dashboard to copy important scripts

## 📊 Monitoring

Vercel provides:
- **Analytics** - View traffic
- **Logs** - Debug issues  
- **Speed Insights** - Performance
- **Function Metrics** - Execution stats

Access: Vercel Dashboard → Your Project → Analytics

## 🚀 Upgrading to Production

1. **Add Database** (MongoDB/PostgreSQL/KV)
2. **Custom Domain** (looks professional)
3. **Rate Limiting** (prevent abuse)
4. **Analytics** (track usage)
5. **Backup Strategy** (protect data)
6. **Monitoring** (catch issues early)

## 💰 Costs

**Vercel Free Tier:**
- ✅ 100GB bandwidth/month
- ✅ 100 GB-hours function execution
- ✅ Unlimited projects
- ✅ HTTPS included

**For Most Users**: Free tier is enough!

**If You Exceed**: Upgrade to Pro ($20/month)

## 🎓 Learning Resources

- [Vercel Docs](https://vercel.com/docs)
- [Python on Vercel](https://vercel.com/docs/functions/serverless-functions/runtimes/python)
- [MongoDB Atlas](https://www.mongodb.com/docs/atlas/)
- [Vercel KV](https://vercel.com/docs/storage/vercel-kv)

## 🤝 Support

Having issues? 

1. Check the [Vercel Status](https://www.vercel-status.com/)
2. Review build logs in dashboard
3. Test locally first
4. Check GitHub Issues

## 📜 License

Free to use and modify!

## 🎉 You're Ready!

1. Push to GitHub ✅
2. Import to Vercel ✅
3. Deploy ✅
4. Get your scripts online ✅

**Happy scripting! 🚀**

---

Made with ❤️ for the Roblox community
